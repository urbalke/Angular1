import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TaskService } from '../services/task.service';
import { Task } from '../model/task';


@Component({
  selector: 'app-todo-task',
  templateUrl: './todo-task.component.html',
  styleUrls: ['./todo-task.component.css']
})
export class TodoTaskComponent implements OnInit {


  tasks: Array<Task> = [];



  


  constructor(private tasksService: TaskService) { 
    this.tasksService.getTasksObs().subscribe((tasks: Array<Task>) => {this.tasks = tasks});
  }

  ngOnInit(): void {
  }

  remove(task: Task){
  this.tasksService.remove(task);
  }
  
  done(task: Task){
  task.end = new Date();
  this.tasksService.done(task);
  }

}
