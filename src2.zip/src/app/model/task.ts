export interface Task {
    name: string;
    created?: string;
    end?: Date;
    
}