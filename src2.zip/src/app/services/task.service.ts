import { Injectable, Input, OnInit } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Task } from '../model/task';

@Injectable()
export class TaskService implements OnInit {
  private tasks: Array<Task> = [];
  private tasksDone: Array<Task> = [];

  private tasksObs = new BehaviorSubject<Array<Task>>([]);
  private tasksDoneObs = new BehaviorSubject<Array<Task>>([]);

  add(task: Task) {
    this.tasks.push(task);
    this.tasksObs.next(this.tasks);

    console.log(this.tasks);
  }

  remove(task: Task) {
    this.tasks = this.tasks.filter((e) => e !== task);
    this.tasksObs.next(this.tasks);
  }

  done(task: Task) {
    this.tasksDone.push(task);
    this.remove(task);
    this.tasksDoneObs.next(this.tasksDone);

    console.log(this.tasksDone);
  }

  constructor() {
    this.tasks = [
      {name: 'Zadanie 1', created: Date()},
      {name: 'Zadanie 2', created: Date()},
      {name: 'Zadanie 3', created: Date()},
    ];
    this.tasksDoneObs.next(this.tasks);
  }

  getTasksObs(): Observable<Array<Task>> {
    return this.tasksObs.asObservable();
  }

  getTasksDoneObs(): Observable<Array<Task>> {
    return this.tasksDoneObs.asObservable();
  }

  ngOnInit(): void {}
}
