import { Component } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HttpService } from './http.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'Serwisy';

  constructor(private httpService: HttpService) { }

  getPosts() {
    this.httpService.getPosts().subscribe((posts) => {
      console.log(posts);
    },
      (error: HttpErrorResponse) => {
        console.log(error.status);
      }
    );
  }

  getPost() {
    this.httpService.getPost(1).subscribe((post) => {
      console.log(post);
    });
  }

  getPostByUser() {
    this.httpService.getPostByUser(1).subscribe((posts) => {
      console.log(posts);
    });
  }

  addPost() {
    const p: Post = ({
      userId: 1,
      id: null,
      title: 'sasas',
      body: 'fadasda',
    });
    this.httpService.addPost(p).subscribe(post => {
      console.log(post);
    });
  }

  updatePost() {
    const r: Post = ({
      userId: 1,
      id: 12,
      title: 'sasas',
      body: 'fadasda',
    });

    this.httpService.updatePost(r).subscribe(post => {
      console.log(post);
    });

  }

  deletePost() {
    this.httpService.deletePost(1).subscribe((post) => {
      console.log(post);
    });
  }

  changePost() {
    const g: Post = ({
      id: 1,
      body: 'zmiana',
    });
    this.httpService.changePost(g).subscribe(post => {
      console.log(post);
    })
  }
}

export interface Post {
  userId?: number;
  id?: number;
  title?: string;
  body?: string;
}
